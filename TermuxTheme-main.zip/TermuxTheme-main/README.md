<https://github.com/Lgithub.com/LeopiTURKEY/IN NIGERIA" src="https://imERIA-green%2CwhiTURKEYgrDu4"ttps://img.shieltle="Version" src="https://een.svg?style=flat-squI/AAAAAAAAAK8/h24GbpmFmjAkZmYE4t6ZKlFAHiE2OU2lQCLcBGAsYHQ/s1280/20210209_1916000.png"></a>
</p>
<p ields.io/badge/YouTube-080HACKERS-red?style=for-the-badge&logo=Youtube"></a>

## AVAILABLE ON :

* Termux Only

### TESTED ON :

* Termux And Not Working On Others Like Kali Linux,ParrotSec,etc

### REQUIREMENTS :
* Python3 pip Lolcat
* Termux
* MKV Installed


## INSTALLATION ON [Termux] :

* `apt-get update -y`
* `apt-get upgrade -y`
* `pkg install python -y`
* `pkg install python2 -y`
* `pkg install git -y`
* `pip install lolcat`
* ` git clone https://github.com/080hackers/TermuxTheme`
* `cd TermuxTheme`
* `chmod 777 *`
* `./setup`
* `ls`
* `./TermuxTheme.sh`
```
THIS TOOL WAS RECODED BY BAJE TECH AND FIRSTLY MADE WITH NOOB HACKERS, IS NOT MADE TO HACK SOMETHING IT'S JUST MADE TO CHANGE YOUR TERMUX THEME TO
LOOK AWEASOME AS YOU DON'T EVER THINK.
```
## WHAT'S NEW WITH THIS VERSION!
* HACK BOX THEME
* EXCAFE BOX FIGLET WITH LOLCAT
* REPLACE COWSAY EYES WITH BOW COW
* TOILET ERRORS IS FIXED NOW
* NOT TAKING MANY TIMES TO INS

## What Fixed?
```
You know the diffault of the tool it's very nice but there's one problem with the version 1
issues like when you want to write something very long as you known what you are writing it's going back
and now that issue is fixed and it's still look awesome
```

## USAGE
* ./TermuxTheme.sh

## SCREENSHOTS [Termux]

<br>
<p align="center">
<img width="60%" src="https://1.bp.blogspot.com/-R0WlLJAlcg4/YCRjLtIR2LI/AAAAAAAAALc/UO_NueuyrWcKLEVL9hmJ9g2CrQMWTDPQQCLcBGAsYHQ/s320/Screenshot_20210209-191454.png"/>
<img width="60%" src="https://1.bp.blogspot.com/-0z8NzbyFobk/YCRjPT6qNpI/AAAAAAAAALg/qy5ntzC2TK0Hh4FJXpTWVs0O3a01Io44QCLcBGAsYHQ/s320/Screenshot_20210209-194237.png"/>
<img width="60%" src="https://1.bp.blogspot.com/-1fvvrQZIJYY/YCRjTaY6dyI/AAAAAAAAALk/ibPW6HV8MI8lxlbAgNUycXFm2G0OiTGcwCLcBGAsYHQ/s320/Screenshot_20210209-194353.png"/>
</p>


## WARNING : 
***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***



## Credits
* Special Thanks To Noob-Hackers
* Special Thanks To Baje Tech


## DONATION
* Bitcoin Donation Address

```31iNfmW5emJRaRBLPy34SPtHwY4bE7yHVe```