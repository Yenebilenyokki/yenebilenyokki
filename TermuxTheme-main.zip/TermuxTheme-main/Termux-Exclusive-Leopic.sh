#!/bin/bash
#coded by Yılmaz Can Sönmez/Leopic 
#Created On 31/03/2021 In Turkey By Yılmaz Can Sönmez
#My Life 31/03/21 This Date Summarizes B♥Y
clear
echo ""
echo " [En büyük savaş, Cahilliğe Karşı Yapılan Savaştır.]"|lolcat
echo "    _____   _____ _   _ _____ __  __ _____"|lolcat
echo "   |_   _| |_   _| | | | ____|  \/  | ____|"|lolcat
echo "     | |_____| | | |_| |  _| | |\/| |  _|"  |lolcat
echo "     | |_____| | |  _  | |___| |  | | |___" |lolcat
echo "     |_|     |_| |_| |_|_____|_|  |_|_____| V1.2"|lolcat
echo "     [Coded By (Yılmaz Can Sönmez)  LEOPİC ONLYN]"|lolcat
sleep 1.0
echo ""
echo "This Will Change Your Termux Home Theme Color To Look Aweasome"|lolcat
echo ""
read -p 'Please Press Enter To Continue Or Press CTRL + Z To Cancel'
echo ""
sleep 0.0
echo "Ok Your Termux Theme Will Change Now"|lolcat
sleep 2.0
echo " Please Wait For 8 Seconds To Make The Change..."|lolcat
cd
cd /$HOME
rm //data/data/com.termux/files/usr/etc/bash.bashrc
cd
mv /data/data/com.termux/files/home/TermuxTheme/code/bash.bashrc //data/data/com.termux/files/usr/etc/bash.bashrc
sleep 8.0
echo "Finished, Your Termux Now Looking Aweasome"|lolcate
sleep 1.0
echo "Due To Confirmination Of This Chnages Your Termux Will Now Close By It Self"|lolcate
echo "In Other To Let You See The Changes"|lolcate
sleep 1.0
echo "Exiting... Please Relounch The Termux Again"|lolcat
echo "Exit From Termux And Open It Again To Se The Changes"|lolcat